


var questionX = prompt ("Сколько калорий ты съел/съела утром?");
questionX = Number.parseInt(questionX);
console.log (questionX)
var questionY = prompt ("Сколько калорий ты съел/съела вечером?");
questionY = Number.parseInt(questionY);
console.log (questionY)


var SUM = alert (questionX + questionY);


			
